package Empresadao;

import java.util.ArrayList;
import java.util.List;
 
import org.bson.Document;
import org.bson.types.ObjectId;
 
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
 
import Empresaconverter.departamentoconverter;
import Empresa.departamento;

public class departamentodao  {
    private MongoCollection<Document> coll;
    
    public departamentodao (MongoClient mongo) {
        this.coll = mongo.getDatabase("Empresa").getCollection("departamento");
    }
    
    public departamento create(departamento d) {
        Document doc = departamentoconverter.toDocument(d);
        this.coll.insertOne(doc);
        ObjectId ide = (ObjectId) doc.get("_id");
        d.setid(ide.toString());
        return (d);
    }
    
    public void update(departamento d) {
        this.coll.updateOne(Filters.eq("_id", new ObjectId(d.getid())), new Document("$set", departamentoconverter.toDocument(d)));
    }
    
    public void delete(String id) {
        this.coll.deleteOne(Filters.eq("_id", new ObjectId(id)));
    }
    
    public boolean exists(String id) {
        FindIterable<Document>  doc = this.coll.find(Filters.eq("_id", id)).limit(1);
        return doc != null;
    }
    
    public List<departamento> getlist() {
        List<departamento> list = new ArrayList<departamento>();
        MongoCursor<Document>  cursor = coll.find().iterator();
        try {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                departamento d = departamentoconverter.todepartamento(doc);
                list.add(d);
            }
        } finally {
            cursor.close();
        }
        return list;
    }
    
    public departamento getdepartamento(String id) {
        Document doc = this.coll.find(Filters.eq("_id", new ObjectId(id))).first();
        return departamentoconverter.todepartamento(doc);
    }
	
}