package Empresaconverter;

import org.bson.Document;
import org.bson.types.ObjectId;

import Empresa.departamento;


public class departamentoconverter {
	
	public static Document toDocument(departamento d) {
		Document doc = new Document("codigo",d.getcodigo()).append("nombredep", d.getnombredep()).append("telefono",d.gettelefono()).append("Ubicacion",d.getubicacion()).append("modulo", d.getmodulo());
		if (d.getid() != null) {
            doc.append("_id", new ObjectId(d.getid()));
        }
        return doc;
    }
	public static departamento todepartamento(Document doc) {
    	departamento d = new departamento();
    	d.setcodigo((String) doc.get("codigo"));
        d.setnombredep((String) doc.get("nombredep"));
        d.settelefono((String) doc.get("telefono"));
        d.setubicacion((String) doc.get("ubicacion"));
        d.setmodulo((String) doc.get("modulo"));
        d.setid(((ObjectId) doc.get("_id")).toString());
        return d;
    }
}
