package Empresa;

public class departamento {

	private String id;
	private String codigo;
	private String nombredep;
	private String telefono;
	private String ubicacion;
	private String modulo;

	public departamento() {
	}

	public departamento(String id, String codigo, String nombredep, String telefono, String ubicacion, String modulo) {
		this.id = id;
		this.codigo = codigo;
		this.nombredep = nombredep;
		this.telefono = telefono;
		this.ubicacion = ubicacion;
		this.modulo = modulo;
	}

	public String getid() {
		return id;
	}

	public void setid(String id) {
		this.id = id;
	}
		
	public String getcodigo() {
		return codigo;
	}

	public void setcodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getnombredep() {
		return nombredep;
	}

	public void setnombredep(String nombredep) {
		this.nombredep = nombredep;
	}

	public String gettelefono() {
		return telefono;
	}

	public void settelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getubicacion() {
		return ubicacion;
	}

	public void setubicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getmodulo() {
		return modulo;
	}

	public void setmodulo(String modulo) {
		this.modulo = modulo;
	}

}